declare module 'react-meta-tags' {
  export default class Meta extends React.Component { }
}