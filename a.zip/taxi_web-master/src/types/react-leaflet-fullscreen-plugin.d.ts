declare module 'react-leaflet-fullscreen-plugin' {
  export default class Fullscreen extends React.Component<any> { }
}