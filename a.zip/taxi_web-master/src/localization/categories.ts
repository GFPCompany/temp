export default [
  'car_models',
  'car_colors',
  'car_classes',
  'booking_comments',
  'booking_driver_states',
  'payment_ways',
  'lang_vls',
]