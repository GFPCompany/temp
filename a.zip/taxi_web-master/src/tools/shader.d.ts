declare module 'shader' {
  export default (color: string, value: number) => string
}